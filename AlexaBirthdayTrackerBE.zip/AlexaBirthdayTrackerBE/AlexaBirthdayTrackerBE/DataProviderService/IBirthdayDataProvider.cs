﻿using AlexaBirthdayTrackerBE.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AlexaBirthdayTrackerBE.DataProviderService
{
    public interface IBirthdayDataProvider
    {
        public void Init();
        public Birthday GetNextBirthday(string userid);
        public Birthday GetBirthday(string name, string userid);
        public bool AddBirthday(Birthday b);
    }
}
