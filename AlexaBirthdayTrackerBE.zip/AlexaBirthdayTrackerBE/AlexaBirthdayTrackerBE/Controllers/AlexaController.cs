﻿using Alexa.NET.Request;
using Alexa.NET.Request.Type;
using Alexa.NET.Response;
using AlexaBirthdayTrackerBE.DataProviderService;
using AlexaBirthdayTrackerBE.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AlexaBirthdayTrackerBE.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class AlexaController : Controller
    {
        IBirthdayDataProvider provider;
        public AlexaController(IBirthdayDataProvider p)
        {
            provider = p;
        }
        [HttpPost,Route("/process")]
        public SkillResponse Process(SkillRequest input)
        {
            SkillResponse output = new SkillResponse();
            output.Version = "1.0";
            output.Response = new ResponseBody();
            string userid= input.Session.User.UserId;
            try
            {
                switch (input.Request.Type)
                {
                    case "LaunchRequest":
                        output.Response.OutputSpeech = new PlainTextOutputSpeech("Hello, Welcome to birthday tracker!! I can help you tracking birthdays!!");
                        output.Response.ShouldEndSession = false;
                        break;
                    case "IntentRequest":
                        IntentRequest intentRequest = (IntentRequest)input.Request;
                        switch (intentRequest.Intent.Name)
                        {
                            case "next_birthday_intent":
                                Birthday b = provider.GetNextBirthday(userid);
                                if (b != null)
                                {
                                    output.Response.OutputSpeech =
                                     new PlainTextOutputSpeech(String.Format("The next birthday is of {0} on {1}", b.Name, b.DateofBirthday.ToString("MMMM dd yyyy")));
                                }
                                else
                                {
                                    output.Response.OutputSpeech =
                                     new PlainTextOutputSpeech("Sorry, No birthdays found!");
                                }
                                output.Response.ShouldEndSession = false;
                                break;
                            case "named_birthday_intent":
                                string name = intentRequest.Intent.Slots["name"].SlotValue.Value;
                                Birthday named = provider.GetBirthday(name, userid);
                                if (named != null)
                                {
                                    output.Response.OutputSpeech =
                                     new PlainTextOutputSpeech(String.Format("Birthday of {0} is on {1}", named.Name, named.DateofBirthday.ToString("MMMM dd yyyy")));
                                }
                                else
                                {
                                    output.Response.OutputSpeech =
                                     new PlainTextOutputSpeech("Sorry, No birthdays found!");
                                }
                                output.Response.ShouldEndSession = false;
                                break;
                            case "add_birthday_intent":

                                if (intentRequest.Intent.ConfirmationStatus == "DENIED")
                                {
                                    output.Response.OutputSpeech =
                                     new PlainTextOutputSpeech("Ok, operation cancelled. Please try again");
                                }
                                else
                                {

                                    Birthday birthday = new Birthday();
                                    birthday.Name = intentRequest.Intent.Slots["name"].Value;
                                    birthday.DateofBirthday = DateTime.Parse(intentRequest.Intent.Slots["birthday"].Value);
                                    birthday.DayOfYear = birthday.DateofBirthday.DayOfYear;
                                    birthday.UserId = userid;
                                    bool success = provider.AddBirthday(birthday);
                                    if (success)
                                    {
                                        output.Response.OutputSpeech =
                                         new PlainTextOutputSpeech("Great! Birthday added!");
                                    }
                                    else
                                    {
                                        output.Response.OutputSpeech =
                                         new PlainTextOutputSpeech("Sorry, could not add that birthday. Please try again");
                                    }
                                }
                                output.Response.ShouldEndSession = false;
                                break;
                            case "AMAZON.StopIntent":
                                output.Response.OutputSpeech =
                                         new PlainTextOutputSpeech("Goodbye! See you soon.");
                                output.Response.ShouldEndSession = true;
                                break;
                            case "AMAZON.FallbackIntent":
                                output.Response.OutputSpeech =
                                    new PlainTextOutputSpeech("Sorry! can you repeat that?");
                                output.Response.ShouldEndSession = false;
                                break;
                            default:
                                output.Response.OutputSpeech =
                                         new PlainTextOutputSpeech("Sorry! I am still learning that. Please try later!");
                                output.Response.ShouldEndSession = false;
                                break;
                        }
                        break;
                }
            }catch(Exception e)
            {
                output.Response.OutputSpeech =
                                    new PlainTextOutputSpeech("Sorry I could not process that. Please try again after some time!");
                output.Response.ShouldEndSession = true;
            }


            
            return output;
        }
    }
}
